I have created a Battle Arena that will allow two heros to fight against each other 
and it will print out there health and power of damage that they are doing to each other
as they continue to fight.  Once the battle is over it will give a winner and tell who 
died from the battle.